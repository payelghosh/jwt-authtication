<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Movie;

class MovieController extends Controller
{
    protected $movie;
    function __construct(Movie $movie) {
        $this->movie = $movie;
    }

    // $this->middleware('checkAdmin', ['only' => ['store', 'update', 'destroy']]);

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      return $this->movie->where('active',1)->get()->toArray();
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
      
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(BrandRequest $request)
    {   
        $this->validate($request, [
            'name' => 'required',
            'active' => 'required',
        ]);

        $movie = new Movie();
        $movie->name = $request->name;
        $movie->description = $request->description;
        $movie->poster = $request->poster;
        $movie->active = $request->active;
     
        if ($this->movie->save($product))
            return response()->json([
                'success' => true,
                'product' => $product
            ]);
        else
            return response()->json([
                'success' => false,
                'message' => 'Sorry, product could not be added'
            ], 500);
    } 

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(BrandRequest $request, $id)
    {
        $movie = $this->movie->find($id);
 
        if (!$movie) {
            return response()->json([
                'success' => false,
                'message' => 'Sorry, movie with id ' . $id . ' cannot be found'
            ], 400);
        }
     
        $updated = $movie->fill($request->all())
            ->save();
     
        if ($updated) {
            return response()->json([
                'success' => true
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Sorry, movie could not be updated'
            ], 500);
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $movie = $this->movie->find($id);
        if (!$movie) {
            return response()->json([
                'success' => false,
                'message' => 'Sorry, movie with id ' . $id . ' cannot be found'
            ], 400);
        }
     
        if ($movie->delete()) {
            return response()->json([
                'success' => true
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'movie could not be deleted'
            ], 500);
        }
    }
}
