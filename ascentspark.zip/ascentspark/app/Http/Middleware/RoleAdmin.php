<?php

namespace App\Http\Middleware;

use Closure;

class RoleAdmin
{
  /**
   * Handle an incoming request.
   *
   * @param  \Illuminate\Http\Request  $request
   * @param  \Closure  $next
   * @return mixed
   */
  public function handle($request, Closure $next)
  {
      if (in_array(auth()->user()->id, \App\Admin::pluck('user_id')->all())) {
          return $next($request); 
      }else{
          auth()->logout();
          return redirect()->route('login')->with('global', 'Email/Password doesnt match')->with('type','danger');
      }
      
  }
}
