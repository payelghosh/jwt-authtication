<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
      /* admin */
      $admin = \App\User::create([
        'name' => 'Admin',
        'email' => 'admin@gmail.com',
        'phone' => '9874563210',
        'password' => Hash::make('123456'),
        'active' => 1,
		    'created_at' => \Carbon::now(),
		    'updated_at' => \Carbon::now()
      ]);
      \App\Admin::create([
    		'user_id' => $admin->id
       ]);

      /* users */
      // \App\User::create([
      //   'name' => 'payel',
      //   'email' => 'payel@gmail.com',
      //   'password' => Hash::make('654321'),
      //   'created_at' => \Carbon::now(),
      //   'updated_at' => \Carbon::now()
      // ]);
    }
}
