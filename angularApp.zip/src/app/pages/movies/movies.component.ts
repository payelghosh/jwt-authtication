import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { AccountService } from '../../services/account.service';
@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {
  movies = null;
  constructor(private accountService: AccountService) { }

  ngOnInit(): void {
    this.accountService.getAll()
            .pipe(first())
            .subscribe(movies => this.movies = movies);
  }

  deleteMovie(id: string) {
    const user = this.movies.find(x => x.id === id);
    user.isDeleting = true;
    this.accountService.delete(id)
        .pipe(first())
        .subscribe(() => {
            this.movies = this.movies.filter(x => x.id !== id) 
        });
}

}


